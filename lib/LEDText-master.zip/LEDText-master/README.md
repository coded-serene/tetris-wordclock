Once you have downloaded the Zip file, it should be extracted into your Arduino Libraries folder and the folder renamed to "LEDText".

For full instructions see the Wiki icon on the right.
